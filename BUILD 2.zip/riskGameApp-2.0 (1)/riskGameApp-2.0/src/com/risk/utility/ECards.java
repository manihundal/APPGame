package com.risk.utility;

/**
 * this is enum for carts it has three types infantry, cavalry, or artillery
 * 
 * @author Kourosh
 * @version 1.0.0.0
 */
public enum ECards {
	Infantry, Cavalry, Artillery

}
