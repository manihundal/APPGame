package com.risk.utility;

public enum TurnPhases {
	Startup, Reinforcement, Fortification, Attack, PreGame, GameOver

}
