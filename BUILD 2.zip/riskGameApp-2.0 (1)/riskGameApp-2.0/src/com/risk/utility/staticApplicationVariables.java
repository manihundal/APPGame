package com.risk.utility;

import com.risk.model.GameBoard;

public class staticApplicationVariables {

	public static int SCREEN_WIDTH = 0;
	public static int SCREEN_HEIGHT = 0;
	public static GameBoard gb = null;
	public static String FILENAME = "";

}
