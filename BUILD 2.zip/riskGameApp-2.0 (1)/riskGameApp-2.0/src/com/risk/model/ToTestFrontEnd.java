package com.risk.model;
/*
 * This class is kept as alternative for initializing
 * 
 */

/**
 * package com.risk.model;
 * 
 * import com.risk.view.applicationWindow;
 * 
 * 
 * public class appInitialize {
 * 
 * 
 * 
 * 
 * public static class Matrix { public static void main(String args[]) {
 * 
 * System.out.println("Game started"); applicationWindow appWindow = new
 * applicationWindow(); appWindow.open();
 * 
 * }
 * 
 * }
 * 
 * }
 */