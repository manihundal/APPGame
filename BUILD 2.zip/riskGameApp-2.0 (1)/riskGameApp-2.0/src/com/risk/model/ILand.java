package com.risk.model;

/**
 * This class represents an interface for continent and country classes This is
 * an interface that continents and countries implement it
 * 
 * @author Kourosh Aziz-Nejad
 * @version 1.0.0.0
 */

public interface ILand {

}
